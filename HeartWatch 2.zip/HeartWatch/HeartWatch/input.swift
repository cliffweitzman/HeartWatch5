//
//  input.swift
//  HeartWatch
//
//  Created by Cliff Weitzman on 2/21/15.
//  Copyright (c) 2015 Cliff Weitzman. All rights reserved.
//

import Cocoa

class input: UIViewController {

}
